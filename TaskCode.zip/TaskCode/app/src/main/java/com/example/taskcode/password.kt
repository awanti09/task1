package com.example.taskcode

class password {
}
package com.example.taskcode

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var  getstart: Button

    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find the "Get Start" button by its ID
        val getstart= findViewById<ImageView>(R.id.getstart)

        // Set the OnClickListener for the button
        getstart.setOnClickListener {
            // Handle button click by starting the Login activity
            val intent = Intent(this, login::class.java)
            startActivity(intent)
        }
    }
}
